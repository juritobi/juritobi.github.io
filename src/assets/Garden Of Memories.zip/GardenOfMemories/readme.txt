

Ya que por falta de tiempo no hay tutorial en el juego te indico los controles y meta del juego.

Se trata de un tower defense, en el que tienes que impedir que los enemigos avancen hasta el nexo (torre).

Para ello tienes que generar plantas que les disparan en los huecos con tierra, y esto te requerirá que gastes recursos.

Los recursos se obtienen de los árboles, que los generan con el tiempo, cada tipo de arbol genera un tipo de recurso (hay 3), y estos
árboles pueden ser también plantados.

Controles:

Movimiento: WASD

Interactuar con la tierra para plantar
o con las plantas para demolerlas: E

Indicar qué vas a plantar: 1, 2, 3, 4, 5 ó 6.

Pausa: ESC